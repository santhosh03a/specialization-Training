import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {
  name:string='santhosh';
  place:string='Bangalore;'

  source:any='assets/animal.jpg'
  high:number=300;
  wid:number=300;

  enable:boolean=true;

  stringData:string='Hello';
  numberData:number=10;
  val:string=' ';
  tname:string='';
  constructor() { }

  ngOnInit(): void {
  }
  getdetails(){
    return `hi this is ${this.name} and im in ${this.place}`;
  }

  getAllData(){
    return `the string is ${this.stringData} and the number is ${this.numberData}`;
}
demo(value:any){
  this.val=value;
  
}
twoway(a:any){
  this.tname=a;
  }

}
