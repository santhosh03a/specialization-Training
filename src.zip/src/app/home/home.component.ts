import { NumberSymbol } from '@angular/common';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  amount:number=0;
  years:number=0;
  res:number=0;
  int:number=0;
  constructor() { }

  ngOnInit(): void {
  }
  calc(value:any,val:any){
    this.amount=value;
    this.years=val;
    this.res=(this.amount*5*this.years)/100;
  }
}
