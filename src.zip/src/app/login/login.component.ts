import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  json=[{'username':'admin','password':'admin'},
  {'username':'abc','password':'abc'},
  {'username':'xyz','password':'xyz'}];
  un:string=' ';
  pw:string=' ';
  flag:boolean=false;
  constructor() { }

  ngOnInit(): void {
  }
  validate(user:string,pass:string){
    for(let i in this.json){
      console.log(i);
      }
    }
    
  }
  

