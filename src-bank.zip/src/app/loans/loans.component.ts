import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loans',
  templateUrl: './loans.component.html',

  styleUrls: ['./loans.component.css']

})
export class LoansComponent implements OnInit {
  amount:any;
  years:any;
  res:any;
  int:any;
  constructor() { }

  ngOnInit(): void {
  }
  calcp(value:any,val:any){
    this.amount=value;
    this.years=val;
    this.res=(this.amount*5*this.years)/100;
  }
    calc(value:any,val:any){
    this.amount=value;
    this.years=val;
    this.res=(this.amount*5*this.years)/100;

    }
    calcc(value:any,val:any){
      this.amount=value;
      this.years=val;
      this.res=(this.amount*10*this.years)/100;
    }


}
