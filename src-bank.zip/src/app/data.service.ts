import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  message:any[]=[];
  constructor() { }
  dataServe(msg:any):void{
    this.message.push(msg);
    
  }
  callData():any{
    return this.message;
  }
}
