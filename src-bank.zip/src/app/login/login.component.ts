import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  json={'username':'admin','password':'admin'};
  str:string=' ';
  flag:boolean=false;
  constructor() { }

  ngOnInit(): void {
  }
  change(){
    if(this.flag){
      this.flag=!this.flag;
    }
    else{
      this.flag=!this.flag;
    }
  }
  validate(user:string,pass:string){
    if(this.json.username==user&&this.json.password==pass){
      this.str='login Successfull';
    }
    else{
      this.str='invalid username or password';
    }
    }
    
  }
  

